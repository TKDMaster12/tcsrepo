import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from 'src/app/models/product/product.module';
import { AuthService, UserDetails } from 'src/app/services/auth/auth.service';
import { CartService } from 'src/app/services/cart/cart.service';
import { WishlistService } from 'src/app/services/wishlist/wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  public products: Array<IProduct> = [];
  userDetails: UserDetails;
  alreadyExists: boolean = false;
  added: boolean = false;

  constructor(protected wishlistService: WishlistService, protected cartService:CartService, protected authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.userDetails = this.authService.getUserDetails();     
    this.loadAll();
  }

  loadAll() {
    this.products = [];
    this.wishlistService.get(this.userDetails._id).then((result:Array<IProduct>) => {
      result.map( subarray => {    
        this.products.push(subarray[0]);
      });
    });
  }

  addToCart(id:string) {
    this.cartService.add(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      if (result.message == 'item added to cart') {
        this.added = true;
        setTimeout(() => {
          this.added = false;
        }, 3000);
      } else if (result.message == 'item already in cart') {
        this.alreadyExists = true;
        setTimeout(() => {
          this.alreadyExists = false;
        }, 3000);
      }
    });
  }

  removeFromWishlist(id:string) {
    this.wishlistService.remove(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      this.loadAll();
    });
  }
}
