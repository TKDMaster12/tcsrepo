import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from 'src/app/models/product/product.module';
import { AuthService, UserDetails } from 'src/app/services/auth/auth.service';
import { CartService } from 'src/app/services/cart/cart.service';
import { WishlistService } from 'src/app/services/wishlist/wishlist.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public products: Array<IProduct> = [];
  public totalprice:number = 0;
  items:number = 0;
  userDetails: UserDetails;
  alreadyExists: boolean = false;
  added: boolean = false;

  constructor(protected cartService: CartService, protected wishlistService: WishlistService, protected authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.userDetails = this.authService.getUserDetails();     
    this.loadAll();
  }

  loadAll() {
    this.products = [];
    this.cartService.get(this.userDetails._id).then((result:Array<IProduct>) => {
      result.map( subarray => {    
        this.products.push(subarray[0]);
      });
    }).then(() => {
      this.calculateTotal();
    });
  }

  addToWishlist(id:string) {
    this.wishlistService.add(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      if (result.message == 'item added to wishlist') {
        this.added = true;
        setTimeout(() => {
          this.added = false;
        }, 3000);
      } else if (result.message == 'item already in wishlist') {
        this.alreadyExists = true;
        setTimeout(() => {
          this.alreadyExists = false;
        }, 3000);
      }
    });
  }

  removeCart(id:string) {
    this.cartService.remove(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      this.loadAll();
    });
  }
  
  onChange(e) {
    let element = e.target.parentNode.parentNode.children[2].children;
    let value = e.target.value;
    let text = element[0].children[1].innerText;
    let array = text.split(' ');
    let number = array[0].split('$');
    let total = number[1] * value;
    element[0].children[0].innerText = "$"+total.toFixed(2);

    this.totalprice = 0;
    this.items = 0;
    var x = document.getElementsByClassName("price");
    for (let i = 0 ; i < x.length; i++) {
      let text = x.item(i).textContent;
      let number = text.split('$');
      this.totalprice += Number(number[1]);
    }
    this.totalprice = Number(this.totalprice.toFixed(2));

    var select = document.getElementsByTagName("select");
    for (let i = 0; i < select.length; i++) {
      this.items += Number(select.item(i).value);
    }

    this.cartService.sendTotal(this.totalprice);
    this.cartService.sendItem(this.items);
  }
  
  calculateTotal() {
    this.totalprice = 0;
    this.items = 0;
    
    this.products.map(element => {
      this.totalprice += element.price;
      this.items++;
    });
    
    this.totalprice = Number(this.totalprice.toFixed(2));;
    this.cartService.sendTotal(this.totalprice);
    this.cartService.sendItem(this.items);
  }
}
