import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, TokenPayload } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  email: FormControl;
  name: FormControl;
  password: FormControl;
  confirmPassword: FormControl;
  error: boolean = false;

  credentials: TokenPayload = {
    email: '',
    name: '',
    password: '',
    role: 'Customer'
  };


  constructor(private router: Router, protected authService: AuthService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    // redirect to home if already logged in
    if (this.authService.isLoggedIn()) { 
      this.router.navigate(['/']);
    }

    this.createFormControls();
    this.initForm();
  }

  onSubmit() {
    this.credentials.email = this.registerForm.value['email'];
    this.credentials.name = this.registerForm.value['name'];
    this.credentials.password = this.registerForm.value['password'];

    this.authService.register(this.credentials).subscribe(() => {
      this.router.navigateByUrl('/home');
    }, (err) => {
      if(err.error.keyPattern.email == 1) {
        this.error = true;
        setTimeout(() => {
          this.error = false;
        }, 3000);
      }
      console.error(err);
    });
  }

  private createFormControls() {
    this.name = new FormControl('', [Validators.required]);
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(6)]);
    this.confirmPassword = new FormControl('', [Validators.required, Validators.minLength(6)]);
  }

  // Init the creation form.
  private initForm() {
    this.registerForm = new FormGroup({
      name: this.name,
      email: this.email,
      password: this.password,
      confirmPassword: this.confirmPassword
    }, {validators: this.checkPasswords});
  }

  private checkPasswords(group: FormGroup) { // here we have the 'passwords' group
    let pass = group.get('password').value;
    let confirmPass = group.get('confirmPassword').value;

    return pass === confirmPass ? null : { notSame: true }     
  }
}
