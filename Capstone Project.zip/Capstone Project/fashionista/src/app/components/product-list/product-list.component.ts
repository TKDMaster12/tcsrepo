import { Component, OnInit } from '@angular/core';
import { IProduct, Product } from 'src/app/models/product/product.module';
import { AuthService, UserDetails } from 'src/app/services/auth/auth.service';
import { CartService } from 'src/app/services/cart/cart.service';
import { ProductService } from 'src/app/services/product/product.service';
import { WishlistService } from 'src/app/services/wishlist/wishlist.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  public products: Array<Product> = [];
  userDetails: UserDetails;
  alreadyExistsCart: boolean = false;
  addedCart: boolean = false;
  alreadyExistsWishlist: boolean = false;
  addedWishlist: boolean = false;

  constructor(protected productService: ProductService, protected cartService: CartService, protected authService: AuthService, protected wishlistService: WishlistService) { }

  ngOnInit(): void {
    this.loadAll();
    this.userDetails = this.authService.getUserDetails();
  }

  //load all products
  private loadAll() {
    this.productService.get().then((result: Array<IProduct>) => {
      this.products = result;
    });
  }

  addToWishlist(id:string) {
    this.wishlistService.add(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      if (result.message == 'item added to wishlist') {
        this.addedWishlist = true;
        setTimeout(() => {
          this.addedWishlist = false;
        }, 3000);
      } else if (result.message == 'item already in wishlist') {
        this.alreadyExistsWishlist = true;
        setTimeout(() => {
          this.alreadyExistsWishlist = false;
        }, 3000);
      }
    });
  }

  addToCart(id:string) {
    this.cartService.add(this.userDetails._id, id).then((result: any) => {
      console.log(result);
      if (result.message == 'item added to cart') {
        this.addedCart = true;
        setTimeout(() => {
          this.addedCart = false;
        }, 3000);
      } else if (result.message == 'item already in cart') {
        this.alreadyExistsCart = true;
        setTimeout(() => {
          this.alreadyExistsCart = false;
        }, 3000);
      }
    });
  }

}
