import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, UserDetails } from 'src/app/services/auth/auth.service';
import { CartService } from 'src/app/services/cart/cart.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  totalAmount:number = 0;
  items:number = 0;
  tax: number = 0;
  checkoutForm: FormGroup;
  cardName: FormControl;
  cardNumber: FormControl;
  cardMonth: FormControl;
  cardYear: FormControl;
  cardCVV: FormControl;
  firstName: FormControl;
  lastName: FormControl;
  email: FormControl;
  phone: FormControl;
  address: FormControl;
  city: FormControl;
  country: FormControl;
  success:boolean = false;
  userDetails: UserDetails;

  constructor(protected cartService: CartService, protected router:Router, protected authService: AuthService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.totalAmount = this.cartService.getTotal();
    this.items = this.cartService.getItem();
    if (this.totalAmount == 0 || this.items == 0) {
      this.router.navigateByUrl("/home");
    }
    this.tax = this.totalAmount * 0.05
    this.tax = Number(this.tax.toFixed(2));
    this.createFormControls();
    this.initForm();
  }

  onSubmit() {
    this.userDetails = this.authService.getUserDetails();  
    this.cartService.empty(this.userDetails._id).then((result: any) => {
      console.log(result);
      this.success = true;
      this.cartService.clearItem();
      this.cartService.clearTotal();
    });
  }

  private createFormControls() {
    this.cardName = new FormControl('', [Validators.required]);
    this.cardMonth = new FormControl('', [Validators.required]);
    this.cardYear = new FormControl('', [Validators.required]);
    this.cardCVV = new FormControl('', [Validators.required]);
    this.cardNumber = new FormControl('', [Validators.required]);
    this.firstName = new FormControl('', [Validators.required]);
    this.lastName = new FormControl('', [Validators.required]);
    this.address = new FormControl('', [Validators.required]);
    this.city = new FormControl('', [Validators.required]);
    this.country = new FormControl('', [Validators.required]);
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.phone = new FormControl('', [Validators.required]);
  }

  // Init the creation form.
  private initForm() {
    this.checkoutForm = new FormGroup({
      cardName: this.cardName,
      cardMonth: this.cardMonth,
      cardYear: this.cardYear,
      cardCVV: this.cardCVV,
      cardNumber: this.cardNumber,
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      phone: this.phone,
      address: this.address,
      city: this.city,
      country: this.country
    });
  }

}
