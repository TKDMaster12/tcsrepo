import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IProduct, Product } from 'src/app/models/product/product.module';
import { ProductService } from 'src/app/services/product/product.service';

@Component({
  selector: 'app-editproducts',
  templateUrl: './editproducts.component.html',
  styleUrls: ['./editproducts.component.css']
})
export class EditproductsComponent implements OnInit, OnChanges {

  products: Array<IProduct> = [];
  editProduct: IProduct = null;
  productForm: FormGroup;
  name:FormControl;
  brand:FormControl;
  description:FormControl;
  price:FormControl;

  @Input() productToDisplay: IProduct = null;

  constructor(protected productService: ProductService) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new product created, we add it to the list.
  ngOnChanges(): void {
    if (this.productToDisplay !== null) {
      this.products.push(this.productToDisplay);
    }
  }

  // Load all products.
  private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }

  // Delete a product. 
  delete(id: string) {
    this.productService.delete(id).then((result: any) => this.loadAll());
  }

  //edit a product
  edit(id:string) {
    this.productService.edit(id).then((result:IProduct) => {
      this.editProduct = result[0];
      this.createFormControls();
      this.initForm();
      this.productForm.get('name').setValue(this.editProduct.name);
      this.productForm.get('brand').setValue(this.editProduct.brand);
      this.productForm.get('description').setValue(this.editProduct.description);
      this.productForm.get('price').setValue(this.editProduct.price);
    });
  }

  private createFormControls() {
    this.name = new FormControl('', Validators.required);
    this.brand = new FormControl('', Validators.required);
    this.description = new FormControl('', Validators.required);
    this.price = new FormControl('', [Validators.required, Validators.min(1)]);
  }

  // Init the creation form.
  private initForm() {
    this.productForm = new FormGroup({
      name: this.name,
      brand: this.brand,
      description: this.description,
      price: this.price
    });
  }

  onEditSubmit() {
    const product = new Product(this.productForm.value['name'], this.productForm.value['brand'], this.productForm.value['description'], this.editProduct.imageName, this.productForm.value['price'], this.editProduct._id);
    this.productService.update(product).then((result: IProduct) => {
      if (result === undefined) {
        console.error("error", result);
      } else {
        console.log("succeess");
          
        this.productForm.get('name').setValue('');
        this.productForm.get('brand').setValue('');
        this.productForm.get('description').setValue('');
        this.productForm.get('price').setValue('');
        this.editProduct = null;
        this.loadAll();
      }
    });
  }
}
