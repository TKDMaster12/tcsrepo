import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IProduct, Product } from 'src/app/models/product/product.module';
import { ProductService } from 'src/app/services/product/product.service';

@Component({
  selector: 'app-createproducts',
  templateUrl: './createproducts.component.html',
  styleUrls: ['./createproducts.component.css']
})
export class CreateproductsComponent implements OnInit {

  productForm: FormGroup;
  name:FormControl;
  brand:FormControl;
  description:FormControl;
  price:FormControl;
  imageName = '';
  imageFile: File = null;

  @Output() createdProduct = new EventEmitter<IProduct>();

  constructor(protected productService: ProductService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.createFormControls();
    this.initForm();
  }

  private createFormControls() {
    this.name = new FormControl('', Validators.required);
    this.brand = new FormControl('', Validators.required);
    this.description = new FormControl('', Validators.required);
    this.price = new FormControl('', [Validators.required, Validators.min(1)]);
  }

  // Init the creation form.
  private initForm() {
    this.productForm = this.formBuilder.group({
      name: this.name,
      brand: this.brand,
      description: this.description,
      imageName: [null, Validators.required],
      imageFile: [''],
      price: this.price
    });
  }

  // Manage the submit action and create the new product.
  onCreateSubmit() {
    this.productService.create(
      this.productForm.value['name'], 
      this.productForm.value['brand'], 
      this.productForm.value['description'],
      this.productForm.value['price'], 
      this.productForm.get('imageFile').value).then((result: IProduct) => {
      if (result === undefined) {
        console.error("error", result);
      } else {
        this.createdProduct.emit(result);
      }
    });
  }

  onFileSelect(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.productForm.patchValue({
        imageFile: file
      });
    }
  }
}
