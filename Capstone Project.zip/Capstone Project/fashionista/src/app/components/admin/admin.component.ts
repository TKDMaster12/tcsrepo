import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, UserDetails } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public details: UserDetails;

  constructor(private authService:AuthService, private router: Router) { }

  ngOnInit(): void {
    if (this.authService.isLoggedIn()) { 
      this.details = this.authService.getUserDetails();
      if (this.details.role !== 'Admin') {
        this.router.navigateByUrl('/home');
      }
    } else {
      this.router.navigateByUrl('/login');
    }
  }
}
