import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminProductsComponent } from './admin-products/admin-products.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminComponent } from './admin.component';
import { EditproductsComponent } from './admin-products/editproducts/editproducts.component';
import { CreateproductsComponent } from './admin-products/createproducts/createproducts.component';
import { CreateusersComponent } from './admin-users/createusers/createusers.component';
import { EditusersComponent } from './admin-users/editusers/editusers.component';

@NgModule({
    declarations: [
        AdminComponent,
        AdminUsersComponent,
        AdminProductsComponent,
        EditproductsComponent,
        CreateproductsComponent,
        CreateusersComponent,
        EditusersComponent
    ],
    imports: [
        CommonModule,
        AdminRoutingModule,
        HttpClientModule,
        ReactiveFormsModule,
        FormsModule
    ],
    providers: []
})

export class AdminModule {}