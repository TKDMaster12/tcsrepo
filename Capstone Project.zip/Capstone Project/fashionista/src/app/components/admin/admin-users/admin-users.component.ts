import { Component, OnInit } from '@angular/core';
import { IUser } from 'src/app/models/user/user.module';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css']
})
export class AdminUsersComponent implements OnInit {

  createdUser: IUser = null;

  constructor() { }

  ngOnInit(): void {
  }

  // Get the new user created.
  onCreatedUser(createdUser: IUser) {
    this.createdUser = createdUser;
  }
}
