import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { IUser, User } from 'src/app/models/user/user.module';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-editusers',
  templateUrl: './editusers.component.html',
  styleUrls: ['./editusers.component.css']
})
export class EditusersComponent implements OnInit, OnChanges {

  users: Array<IUser> = [];
  editUser: IUser = null;
  userForm: FormGroup;
  name:FormControl;
  email:FormControl;
  role:FormControl;

  @Input() userToDisplay: IUser = null;

  constructor(protected userService: UserService, protected formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.loadAll();
  }

  // If new user created, we add it to the list.
  ngOnChanges(): void {
    if (this.userToDisplay !== null) {
      this.users.push(this.userToDisplay);
    }
  }
  
  // Load all users.
  private loadAll() {
    this.userService
    .get()
    .then((result: Array<IUser>) => {
      this.users = result;
    });
  }

  // Delete a user. 
  delete(id: string) {
    this.userService.delete(id).then((result: any) => this.loadAll());
  }

  edit(id:string) {
    this.userService.edit(id).then((result:IUser) => {
      this.editUser = result[0];
      this.createFormControls();
      this.initForm();
      this.userForm.get('name').setValue(this.editUser.name);
      this.userForm.get('email').setValue(this.editUser.email);
      this.userForm.get('role').setValue(this.editUser.role);
    });
  }

  private createFormControls() {
    this.name = new FormControl('', [Validators.required]);
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.role = new FormControl('', Validators.required);
  }

  // Init the creation form.
  private initForm() {
    this.userForm = new FormGroup({
      name: this.name,
      email: this.email,
      role: this.role
    });
  }

  onEditSubmit() {
    const user = new User(this.userForm.value['name'], this.userForm.value['email'], this.editUser.password, this.userForm.value['role'], this.editUser._id);
    this.userService.update(user).then((result: IUser) => {
      if (result === undefined) {
        console.error("error", result);
      } else {
        console.log("succeess");
          
        this.userForm.get('name').setValue('');
        this.userForm.get('email').setValue('');
        this.userForm.get('role').setValue('');
        this.editUser = null;
        this.loadAll();
      }
    });
  }
}
