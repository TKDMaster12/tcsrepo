import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IUser, User } from 'src/app/models/user/user.module';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-createusers',
  templateUrl: './createusers.component.html',
  styleUrls: ['./createusers.component.css']
})
export class CreateusersComponent implements OnInit {

  userForm: FormGroup;
  name:FormControl;
  email:FormControl;
  role:FormControl;
  password: FormControl;
  
  @Output() createdUser = new EventEmitter<IUser>();

  constructor(protected userService: UserService, protected formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.createFormControls();
    this.initForm();
  }

  private createFormControls() {
    this.name = new FormControl('', [Validators.required]);
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(6)]);
    this.role = new FormControl('', Validators.required);
  }

  // Init the creation form.
  private initForm() {
    this.userForm = new FormGroup({
      name: this.name,
      email: this.email,
      password: this.password,
      role: this.role
    });
  }

   // Manage the submit action and create the new user.
   onCreateSubmit() {
    const user = new User(this.userForm.value['name'], this.userForm.value['email'], this.userForm.value['password'], this.userForm.value['role']);
    this.userService.create(user).then((result: IUser) => {
      if (result === undefined) {
        console.error("error", result);
      } else {
        this.createdUser.emit(result);
      }
    });
  }
}
