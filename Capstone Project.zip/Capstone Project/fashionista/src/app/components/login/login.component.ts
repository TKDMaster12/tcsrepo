import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, TokenPayload } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  email: FormControl;
  password: FormControl;
  error: boolean = false;

  credentials: TokenPayload = {
    email: '',
    password: ''
  };

  constructor(private router: Router, protected authService: AuthService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    // redirect to home if already logged in
    if (this.authService.isLoggedIn()) { 
      this.router.navigate(['/']);
    }

    this.createFormControls();
    this.initForm();
  }

  onSubmit() {
    this.credentials.email = this.loginForm.value['email'];
    this.credentials.password = this.loginForm.value['password'];

    this.authService.login(this.credentials).subscribe(() => {
      this.router.navigateByUrl('/products');
    }, (err) => {
      if (err.statusText == "Unauthorized") {
        this.error = true;
        setTimeout(() => {
          this.error = false;
        }, 3000);
        
      }
      console.error(err);
    });
  }

  private createFormControls() {
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(6)]);
  }

  // Init the creation form.
  private initForm() {
    this.loginForm = new FormGroup({
      email: this.email,
      password: this.password
    });
  }
}
