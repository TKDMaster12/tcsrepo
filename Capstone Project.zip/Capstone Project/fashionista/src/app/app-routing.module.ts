import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { CartComponent } from './components/cart/cart.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ProductListComponent } from './components/product-list/product-list.component';
import { RegisterComponent } from './components/register/register.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { AuthGuardService } from './services/auth/auth-guard.service';
import { AuthService } from './services/auth/auth.service';

const routes: Routes = [
  {
    path: '', pathMatch: 'full', redirectTo: 'home'
  },
  {
    path: 'home', pathMatch: 'full', component: HomeComponent
  },
  {
    path: 'products', pathMatch: 'full', component: ProductListComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'cart', pathMatch: 'full', component: CartComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'checkout', pathMatch: 'full', component: CheckoutComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'wishlist', pathMatch: 'full', component: WishlistComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'login', pathMatch: 'full', component: LoginComponent    
  },
  {
    path: 'register', pathMatch: 'full', component: RegisterComponent
  },
  {
    path: 'admin', loadChildren: () => import('./components/admin/admin.module').then(m => m.AdminModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing: false})],
  exports: [RouterModule],
  providers: [AuthService, AuthGuardService],
})
export class AppRoutingModule { }
