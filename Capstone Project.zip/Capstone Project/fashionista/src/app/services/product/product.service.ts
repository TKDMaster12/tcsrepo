import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IProduct, Product } from 'src/app/models/product/product.module';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productsUrl = '/api/products';

  constructor(private http: HttpClient) { }

  // Get products
  get(): Promise<Array<IProduct>> {
    return this.http.get(this.productsUrl)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Edit product
  edit(id: string): Promise<IProduct> {
    return this.http.get(`/api/product/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Create product
  create(name, brand, description, price, file: File): Promise<IProduct> {
    let header = new HttpHeaders();
    let params = new HttpParams();
    const formData = new FormData();
    formData.append('file', file);
    formData.append('name', name);
    formData.append('brand', brand);
    formData.append('description', description);
    formData.append('price', price);

    const options = {
      params,
      headers: header
    };

    return this.http.post('/api/file', formData, options)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //update product
  update(product: Product): Promise<IProduct> {
    return this.http.patch(`${this.productsUrl}/${product._id}`, product)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Delete a product
  delete(id: string): Promise<any> {
    return this.http.delete(`${this.productsUrl}/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message : 
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}