import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IProduct } from 'src/app/models/product/product.module';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartUrl = '/api/cart';
  private totalAmount:number = 0;
  private items:number = 0;

  constructor(private http: HttpClient) { }

  sendTotal(total: number) {
    this.totalAmount = total;;
  }

  getTotal(): number {
    return this.totalAmount;
  }

  clearTotal() {
    this.totalAmount = 0;
  }

  sendItem(item: number) {
    this.items = item;
  }

  getItem():number {
    return this.items;
  }

  clearItem() {
    this.items = 0;
  }

   // Get Cart
   get(id: string): Promise<Array<IProduct>> {
    return this.http.get(`${this.cartUrl}/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //add item Cart
  add(userId:string, productId:string): Promise<any> {
    return this.http.post(this.cartUrl, {'userId':userId, 'productId':productId})
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  empty(userId:string): Promise<any> {
    return this.http.delete(`/api/allcart/${userId}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //remove item Cart
  remove(userId:string, productId:string): Promise<any> {
    return this.http.delete(`${this.cartUrl}/${userId}/${productId}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message : 
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
