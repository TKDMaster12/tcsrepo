import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IUser, User } from 'src/app/models/user/user.module';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userUrl = '/api/users';

  constructor(private http: HttpClient) { }

   // Get products
   get(): Promise<Array<IUser>> {
    return this.http.get(this.userUrl)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //edit user
  edit(id: string): Promise<IUser> {
    return this.http.get(`/api/user/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Create user
  create(user: User): Promise<IUser> {
    return this.http.post(this.userUrl, user)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //update user
  update(user: User): Promise<IUser> {
    return this.http.patch(`${this.userUrl}/${user._id}`, user)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Delete a user
  delete(id: string): Promise<any> {
    return this.http.delete(`${this.userUrl}/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

   // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message : 
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
