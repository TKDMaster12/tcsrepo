import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IProduct } from 'src/app/models/product/product.module';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  private wishlistUrl = '/api/wishlist';

  constructor(private http: HttpClient) { }

   // Get Wishlist
   get(id: string): Promise<Array<IProduct>> {
    return this.http.get(`${this.wishlistUrl}/${id}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  //add Wishlist
  add(userId:string, productId:string): Promise<any> {
    return this.http.post(this.wishlistUrl, {'userId':userId, 'productId':productId})
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }
  
  //remove item wishlist
  remove(userId:string, productId:string): Promise<any> {
    return this.http.delete(`${this.wishlistUrl}/${userId}/${productId}`)
    .toPromise()
    .then(response => JSON.parse(JSON.stringify(response)))
    .catch(this.error);
  }

  // Error handling
  private error(error: any) {
    let message = (error.message) ? error.message : 
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(message);
  }
}
