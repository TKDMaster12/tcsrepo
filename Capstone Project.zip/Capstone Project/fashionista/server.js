const express = require("express");
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var cors = require('cors');
var passport = require('passport');

//data base model
require('./api/models/db');
require('./api/config/passport');

var routesApi = require('./api/routes/index');

var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());

// Initialise Passport before using the route middleware
app.use(passport.initialize());

const distDir = __dirname + "/dist/";
app.use(express.static(distDir));

app.use('/api', routesApi);

var CartCollection = 'carts';
var WishListCollection = 'wishlists';
var OrdersCollection = 'orders';

const LOCAL_PORT = 8080;

// Initialize the app.
var server = app.listen(process.env.PORT || LOCAL_PORT, function () {
    let port = server.address().port;
    console.log("App now running on port", port);
});