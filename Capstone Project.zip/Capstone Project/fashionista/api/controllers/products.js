var mongoose = require('mongoose');
var Product = mongoose.model('Product');
var ObjectID = mongoose.mongo.ObjectID;

/*  "/api/products"
 *  GET: finds all products
 */
module.exports.productRead = function(req, res) {
    Product.find({}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get products"
            });
        } else {
            res.status(200).json(data);
        }
    });
};

/*  "/api/product/id"
 *  GET: finds one product
 */
module.exports.productGet = function(req, res) {
    Product.find({ _id: new ObjectID(req.params.id) }).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get product"
            });
        } else {
            res.status(200).json(data);
        }
    });
};

/*  "/api/products"
 *   PATCH: updates a product
 */
module.exports.productUpdate = function(req, res) {
    let product = req.body;

    if (!product.name) {
        res.status(401).json({"message" : "Invalid product input: Name is mandatory."});
    } else if (!product.brand) {
        res.status(401).json({"message" : "Invalid product input: Brand is mandatory."});
    } else if (!product.price) {
        res.status(401).json({"message" : "Invalid product input: Price is mandatory."});
    } else if (!product.description) {
        res.status(401).json({"message" : "Invalid product input: Description is mandatory."});
    } else {
        Product.where('_id', product._id).updateOne({name: product.name, brand: product.brand, description: product.description, price: product.price }, function (err, doc) {
            if (err) {
                res.status(401).json({
                    "message" : "Failed to update product"
                });
            } else {
                res.status(201).json({"message" : "Success to update product"});
            }
        });
    }
};

/*  "/api/products/:id"
 *   DELETE: deletes product by id
 */
module.exports.productDelete = function(req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        res.status(401).json({"message" : "Invalid product id: ID must be a single String of 12 bytes or a string of 24 hex characters."});
    } else {
        Product.deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                res.status(401).json({ 'message' : `${err.message} : Failed to delete product.` });
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};