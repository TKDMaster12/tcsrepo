var mongoose = require('mongoose');
var Cart = mongoose.model('Cart');
var Product = mongoose.model('Product');
var ObjectID = mongoose.mongo.ObjectID;

module.exports.cartGet = function(req, res) {
    var cartList = [];
    Cart.find({userId: req.params.userId}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get cart items"
            });
        } else {
            var bar = new Promise((resolve, reject) => {
                data.forEach((element, index, array) => {
                    Product.find({_id: new ObjectID(element.productId)}).exec(function(err, data) {
                        if (err) {
                            res.status(401).json({
                                "message" : "Failed to get cart items"
                            });
                        } 
                        cartList.push(data);
                        if (index === array.length -1) resolve();
                    });
                });
            }).then(() => {
                res.status(200).json(cartList);
            });
        }
    });
};

module.exports.cartAdd = function(req, res) {
    Cart.find({userId: req.body.userId, productId: req.body.productId}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get cart items"
            });
        } else {
            if (data === undefined || data.length == 0) {
                cart = new Cart();
                cart.userId = req.body.userId;
                cart.productId = req.body.productId;
                Cart.create(cart, function (err, doc) {
                    if (err) {
                        res.status(401).json({
                            "message" : "Failed to add to cart"
                        });
                    } else {
                        res.status(201).json({"message":"item added to cart"});
                    }
                });
            } else {
                res.status(201).json({"message":"item already in cart"});
            }           
        }
    });
};

/*  "/api/cart/:id/:id"
 *   DELETE: remove item by id
 */
module.exports.cartRemove = function(req, res) {
    Cart.deleteOne({userId: req.params.userId, productId: req.params.productId}, function (err, result) {
        if (err) {
            console.log(err);
            res.status(401).json({ 'message' : `${err.message} : Failed to delete product.` });
        } else {
            res.status(200).json({"message" : "item removed from cart"});
        }
    });
};

module.exports.cartEmpty = function(req, res) {
    Cart.deleteMany({userId: req.params.userId}, function (err, result) {
        if (err) {
            console.log(err);
            res.status(401).json({ 'message' : `${err.message} : Failed to delete product.` });
        } else {
            res.status(200).json({"message" : "all items removed from cart"});
        }
    });
};