var mongoose = require('mongoose');
var Wishlist = mongoose.model('Wishlist');
var Product = mongoose.model('Product');
var ObjectID = mongoose.mongo.ObjectID;

module.exports.wishlistGet = function(req, res) {
    var wishlistList = [];
    Wishlist.find({userId: req.params.userId}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get wishlist items"
            });
        } else {
            var bar = new Promise((resolve, reject) => {
                data.forEach((element, index, array) => {
                    Product.find({_id: new ObjectID(element.productId)}).exec(function(err, data) {
                        if (err) {
                            res.status(401).json({
                                "message" : "Failed to get wishlist items"
                            });
                        } 
                        wishlistList.push(data);
                        if (index === array.length -1) resolve();
                    });
                });
            }).then(() => {
                res.status(200).json(wishlistList);
            });
        }
    });
};

module.exports.wishlistAdd = function(req, res) {
    Wishlist.find({userId: req.body.userId, productId: req.body.productId}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get wishlist items"
            });
        } else {
            if (data === undefined || data.length == 0) {
                wishlist = new Wishlist();
                wishlist.userId = req.body.userId;
                wishlist.productId = req.body.productId;
                Wishlist.create(wishlist, function (err, doc) {
                    if (err) {
                        res.status(401).json({
                            "message" : "Failed to add to wishlist"
                        });
                    } else {
                        res.status(201).json({"message":"item added to wishlist"});
                    }
                });
            } else {
                res.status(201).json({"message":"item already in wishlist"});
            }           
        }
    });
};

/*  "/api/wishlist/:id/:id"
 *   DELETE: remove item by id
 */
module.exports.wishlistRemove = function(req, res) {
    Wishlist.deleteOne({userId: req.params.userId, productId: req.params.productId}, function (err, result) {
        if (err) {
            console.log(err);
            res.status(401).json({ 'message' : `${err.message} : Failed to delete product.` });
        } else {
            res.status(200).json({"message" : "item removed from wishlist"});
        }
    });
};