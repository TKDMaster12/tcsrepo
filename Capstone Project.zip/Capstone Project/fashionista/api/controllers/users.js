var mongoose = require('mongoose');
var User = mongoose.model('User');
var ObjectID = mongoose.mongo.ObjectID;

/*  "/api/users"
 *  GET: finds all users
 */
module.exports.userRead = function(req, res) {
    User.find({}).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get users"
            });
        } else {
            res.status(200).json(data);
        }
    });
};

/*  "/api/users/id"
 *  GET: finds one users
 */
module.exports.userGet = function(req, res) {
    User.find({ _id: new ObjectID(req.params.id) }).exec(function(err, data) {
        if (err) {
            res.status(401).json({
                "message" : "Failed to get users"
            });
        } else {
            res.status(200).json(data);
        }
    });
};

/*  "/api/users"
 *   POST: creates a new user
 */
module.exports.userCreate = function(req, res) {
    let user = req.body;

    if (!user.name) {
        res.status(401).json({"message" : "Invalid user input: Name is mandatory."});
    } else if (!user.email) {
        res.status(401).json({"message" : "Invalid user input: Email is mandatory."});
    } else {

        var user2 = new User();
        user2.name = user.name;
        user2.email = user.email;
        user2.role = user.role;
        user2.setPassword(user.password);

        user2.save(function (err, doc) {
            if (err) {
                res.status(401).json({
                    "message" : "Failed to create new user"
                });
            } else {
                res.status(201).json({"message" : "Success to create new user"});
            }
        });
    }
};

/*  "/api/users"
 *   POST: updates a new user
 */
module.exports.userUpdate = function(req, res) {
    let user = req.body;

    if (!user.name) {
        res.status(401).json({"message" : "Invalid user input: Name is mandatory."});
    } else if (!user.email) {
        res.status(401).json({"message" : "Invalid user input: Email is mandatory."});
    } else {

        User.where('_id', user._id).updateOne({name: user.name, email: user.email, role: user.role}, function (err, doc) {
            if (err) {
                res.status(401).json({
                    "message" : "Failed to update user"
                });
            } else {
                res.status(201).json({"message" : "Success to update new user"});
            }
        });
    }
};

/*  "/api/users/:id"
 *   DELETE: deletes user by id
 */
module.exports.userDelete = function(req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        res.status(401).json({"message" : "Invalid user id: ID must be a single String of 12 bytes or a string of 24 hex characters."});
    } else {
        User.deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                res.status(401).json({ 'message' : `${err.message} : Failed to delete user.` });
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};