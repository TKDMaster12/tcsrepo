var express = require('express');
var mongoose = require('mongoose');
var multer = require('multer');
var router = express.Router();
var Product = mongoose.model('Product');
var jwt = require('express-jwt');
var auth = jwt ({
    secret: 'MY_SECRET',
    userProperty: 'payload',
    algorithms: ['HS256']
});

var ctrlProfile = require('../controllers/profile');
var ctrlAuth = require('../controllers/authentication');
var ctrlProduct = require('../controllers/products');
var ctrlUser = require('../controllers/users');
var ctrlCart = require('../controllers/cart');
var ctrlWishlist = require('../controllers/wishlist');

var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'C:/Capstone Project/fashionista/src/assets/images')
    },
    filename: (req, file, cb) => {
        var fileType = '';
        if(file.mimetype === 'image/gif') {
            fileType = 'gif';
        }
        else if(file.mimetype === 'image/png') {
            fileType = 'png';
        }
        else if(file.mimetype === 'image/jpg') {
            fileType = 'jpg';
        } 
        else if(file.mimetype === 'image/jpeg') {
            fileType = 'jpeg';
        } 

        cb(null, 'image-' + Date.now() + '.' + fileType);
    }
});

var upload = multer({storage: storage});

router.get('/profile', auth, ctrlProfile.profileRead);

//auth
router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);

//get all products
router.get('/products', ctrlProduct.productRead);
//get one product by id
router.get('/product/:id', ctrlProduct.productGet);
//updte product
router.patch('/products/:id', ctrlProduct.productUpdate);
//delete product
router.delete('/products/:id', ctrlProduct.productDelete);

//get all users
router.get('/users', ctrlUser.userRead);
//get one user by id
router.get('/user/:id', ctrlUser.userGet);
//create user
router.post('/users', ctrlUser.userCreate);
//update user
router.patch('/users/:id', ctrlUser.userUpdate);
//delete user
router.delete('/users/:id', ctrlUser.userDelete);

//get cart products
router.get('/cart/:userId', ctrlCart.cartGet);
//add to cart
router.post('/cart', ctrlCart.cartAdd);
//delete cart products
router.delete('/cart/:userId/:productId', ctrlCart.cartRemove);
//empty all cart
router.delete('/allcart/:userId', ctrlCart.cartEmpty);

//get wishlist products
router.get('/wishlist/:userId', ctrlWishlist.wishlistGet);
//add to wishlist
router.post('/wishlist', ctrlWishlist.wishlistAdd);
//delete wishlist products
router.delete('/wishlist/:userId/:productId', ctrlWishlist.wishlistRemove);


//upload image
router.post('/file', upload.single('file'), (req, res, next) => {
    const file = req.file;

    let product = req.body;
    if (!product.name) {
        res.status(401).json({"message" : "Invalid product input: Name is mandatory."});
    } else if (!product.brand) {
        res.status(401).json({"message" : "Invalid product input: Brand is mandatory."});
    } else if (!product.description) {
        res.status(401).json({"message" : "Invalid product input: Description is mandatory."});
    } else if (!product.price) {
        res.status(401).json({"message" : "Invalid product input: Price is mandatory."});
    } else {
        product2 = new Product();
        product2.name = product.name;
        product2.brand = product.brand;
        product2.description = product.description;
        product2.price = product.price;
        product2.imageName = file.filename;

        Product.create(product2, function (err, doc) {
            if (err) {
                res.status(401).json({
                    "message" : "Failed to create new products"
                });
            } else {
                res.status(201).json(doc.ops);
            }
        });
    }
});

module.exports = router;