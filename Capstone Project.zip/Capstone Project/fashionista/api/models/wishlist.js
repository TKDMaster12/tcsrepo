var mongoose = require('mongoose');

var wishlistSchema = new mongoose.Schema({
    userId: {
      type: String,
      required: true
    },
    productId: {
      type: String,
      required: true
    }
  });

  mongoose.model('Wishlist', wishlistSchema);