var mongoose = require('mongoose');

var productSchema = new mongoose.Schema({
    name: {
      type: String,
      unique: true,
      required: true
    },
    brand: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    imageName: {
      type: String,
      required: true
    },
    price: {
        type: Number,
        required: true
    }
  });

  mongoose.model('Product', productSchema);