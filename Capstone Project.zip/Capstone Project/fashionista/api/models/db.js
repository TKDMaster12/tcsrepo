var mongoose = require('mongoose');
var dbURI = "mongodb+srv://admin:admin123@cluster0.uqtjn.mongodb.net/tcsdb?retryWrites=true&w=majority";
mongoose.connect(dbURI, {useUnifiedTopology: true, useNewUrlParser: true});

mongoose.connection.on('connected', function() {
    console.log("Mongoose is connected");
});

mongoose.connection.on('error', function() {
    console.log("Mongoose connection error");
});

mongoose.connection.on('disconnected', function() {
    console.log("Mongoose disconnected");
});

require('./users');
require('./product');
require('./cart');
require('./wishlist');